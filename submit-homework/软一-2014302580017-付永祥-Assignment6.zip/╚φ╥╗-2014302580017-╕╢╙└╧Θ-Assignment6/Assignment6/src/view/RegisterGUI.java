package view;

import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Authentication.EmailAutentication;
import bean.User;
import database.AccessDB;

public class RegisterGUI {

	private JFrame frame;
	private JTextField txtUser;
	private JPasswordField txtPwd;
	private JPasswordField txtPwdRe;
	private JTextArea textArea;
	private JTextArea textArea_1;
	private JLabel lblEmail;
	private JTextField txtEmail;
	private JButton btnNewButton;
	private JLabel lblCaptcha;
	private JTextField txtCaptcha;
	private JButton btnRegister;
	private int captcha;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegisterGUI window = new RegisterGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/

	/**
	 * Create the application.
	 */
	public RegisterGUI() {
		initialize();
		frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 659, 479);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblUser = new JLabel("\u8BF7\u8F93\u5165\u7528\u6237\u540D");
		lblUser.setBounds(81, 39, 107, 18);
		frame.getContentPane().add(lblUser);

		JLabel lblPwd = new JLabel("\u8BF7\u8F93\u5165\u5BC6\u7801");
		lblPwd.setBounds(81, 106, 107, 18);
		frame.getContentPane().add(lblPwd);

		JLabel lblPwdRe = new JLabel("\u8BF7\u518D\u6B21\u8F93\u5165\u5BC6\u7801");
		lblPwdRe.setBounds(81, 166, 128, 18);
		frame.getContentPane().add(lblPwdRe);

		txtUser = new JTextField();
		txtUser.setBounds(245, 36, 178, 24);
		frame.getContentPane().add(txtUser);
		txtUser.setColumns(10);

		txtPwd = new JPasswordField();
		txtPwd.setBounds(245, 103, 178, 24);
		frame.getContentPane().add(txtPwd);
		txtPwd.setColumns(10);

		txtPwdRe = new JPasswordField();
		txtPwdRe.setBounds(245, 163, 178, 24);
		frame.getContentPane().add(txtPwdRe);
		txtPwdRe.setColumns(10);

		textArea = new JTextArea();
		textArea.setText("\u957F\u5EA6\u4E0D\u80FD\u5927\u4E8E40\u5B57\u7B26");
		textArea.setEditable(false);
		textArea.setBackground(SystemColor.menu);
		textArea.setBounds(439, 37, 156, 24);
		frame.getContentPane().add(textArea);

		textArea_1 = new JTextArea();
		textArea_1.setText(
				"\u957F\u5EA6\u4E3A6-16\u4E2A\u5B57\u7B26\n\u4E0D\u80FD\u5305\u542B\u7A7A\u683C\n\u4E0D\u80FD\u662F9\u4F4D\u4EE5\u4E0B\u7EAF\u6570\u5B57");
		textArea_1.setEditable(false);
		textArea_1.setBackground(SystemColor.menu);
		textArea_1.setBounds(437, 116, 158, 61);
		frame.getContentPane().add(textArea_1);

		lblEmail = new JLabel("\u8BF7\u8F93\u5165\u90AE\u7BB1");
		lblEmail.setBounds(81, 233, 107, 18);
		frame.getContentPane().add(lblEmail);

		txtEmail = new JTextField();
		txtEmail.setBounds(245, 230, 213, 24);
		frame.getContentPane().add(txtEmail);
		txtEmail.setColumns(10);

		btnNewButton = new JButton("\u70B9\u51FB\u83B7\u53D6\u9A8C\u8BC1\u7801");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				EmailAutentication ea = EmailAutentication.getInstance(txtEmail.getText());
				captcha = ea.authenticate();
			}
		});
		btnNewButton.setBounds(411, 294, 139, 27);
		frame.getContentPane().add(btnNewButton);

		lblCaptcha = new JLabel("\u8BF7\u8F93\u5165\u9A8C\u8BC1\u7801");
		lblCaptcha.setBounds(81, 298, 107, 18);
		frame.getContentPane().add(lblCaptcha);

		txtCaptcha = new JTextField();
		txtCaptcha.setBounds(242, 295, 107, 24);
		frame.getContentPane().add(txtCaptcha);
		txtCaptcha.setColumns(10);

		btnRegister = new JButton("\u70B9\u51FB\u6CE8\u518C");
		btnRegister.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String username = txtUser.getText().trim();
				String pwd = new String(txtPwd.getPassword());
				String pwdRe = new String(txtPwdRe.getPassword());

				String pwdPattern1 = "[\\d]{0,9}";
				String pwdPattern2 = "[\\S]{6,16}";

				if (pwd.equals(pwdRe))
					if (!pwd.matches(pwdPattern1) && pwd.matches(pwdPattern2) && username.length() < 40) {
						try {
							int hisCaptcha = Integer.parseInt(txtCaptcha.getText());
							if (hisCaptcha == captcha) {
								//�����ݿ��������
								String email = txtEmail.getText();
								
								AccessDB adb = new AccessDB();
								int id = adb.Register(username, pwd, email);
								User user = User.getUserById(id); 
								adb.close();
								
								JOptionPane.showMessageDialog(frame, "��ϲ���ɹ�ע���˺ţ���������������ѡ����ϲ���ĳ�����", "ע��ɹ�", JOptionPane.CLOSED_OPTION);
								new StoreGUI(user);
								frame.dispose();
								
								return;
							}// end of third if

						} catch (NumberFormatException ex) {
							JOptionPane.showMessageDialog(frame, "��֤���ʽ����", "ע��ʧ��", JOptionPane.ERROR_MESSAGE);
							return;
						}// end of try
					}// end of second if
					// end of first if
				JOptionPane.showMessageDialog(frame, "������������Ϣ��ȷ��������Ϣ����Ҫ��", "ע��ʧ��", JOptionPane.ERROR_MESSAGE);
			}

		});
		btnRegister.setBounds(269, 371, 113, 27);
		frame.getContentPane().add(btnRegister);
	}

}
