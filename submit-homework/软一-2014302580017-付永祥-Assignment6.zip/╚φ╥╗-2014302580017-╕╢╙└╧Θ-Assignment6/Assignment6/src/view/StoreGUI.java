package view;

import java.awt.Container;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.ScrollPaneLayout;
import javax.swing.SwingConstants;

import bean.Pet;
import bean.User;
import database.AccessDB;
import view.model.MyPanel;

public class StoreGUI {

	private JFrame frame;
	private User user;
	private JPanel panelMain;
	private Vector<Pet> pets;
	private JLabel lblBalance;
	private StoreGUI me;

	/**
	 * Launch the application.
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StoreGUI window = new StoreGUI(null);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	public User getUser() {
		return user;
	}

	public Vector<Pet> getPets() {
		return pets;
	}

	public JLabel getLblBalance() {
		return lblBalance;
	}

	/**
	 * Create the application.
	 */
	public StoreGUI(User user) {
		this.user = user;
		initialize();
		frame.setVisible(true);
		me = this;
	}
	
	public JPanel getInfoPanel(){
		return panelMain;
	}
	
	private Map<Integer,Integer> getSelectedPet(){
		Map<Integer,Integer> map = new HashMap<>();
		for(int i=0;i<panelMain.getComponentCount();i++){
			Container panel = (Container) panelMain.getComponent(i);
			
			//S/ystem.out.println("i="+i+" pane:"+panel+" count="+panel.getComponentCount());
			JSpinner spinner = (JSpinner) panel.getComponent(0);
			int value = (int) spinner.getValue();
			if(value != 0)
				map.put(i+1, value);
		}
		return map;
	}
	
	public void initSelectedPet(){
		for(int i=0;i<panelMain.getComponentCount();i++){
			Container panel = (Container) panelMain.getComponent(i);
			JSpinner spinner = (JSpinner) panel.getComponent(0);
			spinner.setValue(0);
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1193, 753);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setTitle("QPet�������������ƽ̨");
		
		JLabel lblQpet = new JLabel("QPet\u5BA0\u7269\u5E97\u7F51\u7EDC\u552E\u5356\u5E73\u53F0");
		lblQpet.setBounds(447, 14, 242, 26);
		lblQpet.setFont(new Font("����", Font.PLAIN, 22));
		lblQpet.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblQpet);
	    
	    JScrollPane scrollPane = new JScrollPane();
	    scrollPane.setBounds(38, 102, 1083, 500);
	    scrollPane.setLayout(new ScrollPaneLayout());
	    frame.getContentPane().add(scrollPane);
	    
	    panelMain = new JPanel();
	    scrollPane.setViewportView(panelMain);
	    panelMain.setLayout(null);
	    
	     MyPanel.init(panelMain);;
	  
	    
	    JButton btnBuy = new JButton("\u7ACB\u5373\u8D2D\u4E70");
	    btnBuy.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	    		user.addToCart(getSelectedPet());
	    		int sum = user.totalCost(pets);
	    		if(sum > user.getMoney()){
	    			JOptionPane.showMessageDialog(frame, "����", "����ʧ��", JOptionPane.ERROR_MESSAGE);
	    		}
	    		else{
	    			if(sum == 0) {
	    				JOptionPane.showMessageDialog(frame, "����δѡ���κγ���", "����ʧ��", JOptionPane.ERROR_MESSAGE);
	    				return;
	    			}
	    			
	    			//ˢ�������Ϣ
	    			user.setMoney(user.getMoney()-sum);
	    			user.addToCart(null);
	    			lblBalance.setText("�𾴵�"+user.getUsername()+",�������Ϊ��"+user.getMoney());
	    			
	    			AccessDB adb = new AccessDB();
	    			adb.flushUser(user.getId(), user.getMoney());
	    			JOptionPane.showMessageDialog(frame, "����ɹ�", "����ɹ�", JOptionPane.CLOSED_OPTION);
	    			//ˢ�³�����Ϣ
	    			initSelectedPet();
	    		}
	    	}
	    });
	    btnBuy.setBounds(683, 615, 133, 47);
	    frame.getContentPane().add(btnBuy);
	   
	    
	    
	    JButton btnAddToCart = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");
	    btnAddToCart.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	    		user.addToCart(getSelectedPet());
	    	}
	    });
	    btnAddToCart.setBounds(921, 615, 133, 47);
	    frame.getContentPane().add(btnAddToCart);
	    
	    JButton btnCart = new JButton("\u6211\u7684\u8D2D\u7269\u8F66");
	    btnCart.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	    		new CartGUI(me);//lblBalance,user,pets);
	    	}
	    });
	    btnCart.setBounds(962, 13, 143, 34);
	    frame.getContentPane().add(btnCart);
	    
	    lblBalance = new JLabel("�𾴵�"+user.getUsername()+",�������Ϊ��"+user.getMoney());
	    lblBalance.setBounds(38, 614, 453, 18);
	    frame.getContentPane().add(lblBalance);	    
	    
	    JLabel lblId = new JLabel("Id");
	    lblId.setToolTipText("");
	    lblId.setBounds(38, 63, 72, 18);
	    frame.getContentPane().add(lblId);
	    
	    JLabel lblName = new JLabel("Name");
	    lblName.setBounds(95, 63, 72, 18);
	    frame.getContentPane().add(lblName);
	    
	    JLabel lblEat = new JLabel("Eat");
	    lblEat.setBounds(210, 63, 72, 18);
	    frame.getContentPane().add(lblEat);
	    
	    JLabel lblDrink = new JLabel("Drink");
	    lblDrink.setBounds(396, 63, 72, 18);
	    frame.getContentPane().add(lblDrink);
	    
	    JLabel lblLive = new JLabel("Live");
	    lblLive.setBounds(529, 63, 72, 18);
	    frame.getContentPane().add(lblLive);
	    
	    JLabel lblHobby = new JLabel("Hobby");
	    lblHobby.setBounds(809, 63, 72, 18);
	    frame.getContentPane().add(lblHobby);
	    
	    JLabel lblPrice = new JLabel("Price");
	    lblPrice.setBounds(962, 63, 72, 18);
	    frame.getContentPane().add(lblPrice);
	    
	    JButton btnlogout = new JButton("\u6CE8\u9500");
	    btnlogout.addMouseListener(new MouseAdapter() {
	    	@Override
	    	public void mouseClicked(MouseEvent e) {
	    		new loginGUI();
	    		me.frame.dispose();
	    	}
	    });
	    btnlogout.setBounds(38, 16, 113, 27);
	    frame.getContentPane().add(btnlogout);
	    pets = new Vector<Pet>();
	    AccessDB adb = new AccessDB();
		ResultSet rs = adb.getPets();
	    
		try {
			while(rs.next()){
				Pet pet = new Pet(rs.getInt("id"), rs.getString("name"), rs.getString("eat"), rs.getString("drink"), rs.getString("live"), rs.getString("hobby"),rs.getInt("price"));
				pets.addElement(pet);
				
				new MyPanel(pet.toString());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		adb.close();
	    
		
	}
}
