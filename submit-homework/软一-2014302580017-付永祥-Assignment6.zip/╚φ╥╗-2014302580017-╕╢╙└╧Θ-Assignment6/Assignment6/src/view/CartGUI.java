package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

import bean.Pet;
import bean.User;
import database.AccessDB;

public class CartGUI extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6587003967781134194L;

	private final JScrollPane contentPanel = new JScrollPane();
	private User user;
	private Vector<Pet> pets;
	private CartGUI dialog = null;
	private JLabel label = null;
	private StoreGUI father;

	private JButton okButton;

	private JTextPane txtCart;

	/**
	 * Launch the application.
	 * 
	 * public static void main(String[] args) { try { CartGUI dialog = new
	 * CartGUI(null,null); dialog.dispose();
	 * //dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	 * //dialog.setVisible(true); } catch (Exception e) { e.printStackTrace(); }
	 * }
	 */

	/**
	 * Create the dialog.
	 */
	public CartGUI(StoreGUI father){//JLabel jlabel, User user, Vector<Pet> pets) {
		this.father = father;
		this.user = father.getUser();
		this.pets = father.getPets();
		this.dialog = this;
		this.label = father.getLblBalance();

		setTitle("\u6211\u7684\u8D2D\u7269\u8F66");
		setBounds(100, 100, 623, 328);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		//contentPanel.setLayout(new ScrollPaneLayout());
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("\u4E00\u952E\u8D2D\u4E70");
				okButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						if (okButton.isEnabled()) {
							int sum = user.totalCost(pets);
							if (sum > user.getMoney()) {
								JOptionPane.showMessageDialog(null, "����", "����ʧ��", JOptionPane.ERROR_MESSAGE);
							} else {
								user.setMoney(user.getMoney() - sum);
								user.addToCart(null);
								label.setText("�𾴵�" + user.getUsername() + ",�������Ϊ��" + user.getMoney());

								AccessDB adb = new AccessDB();
								adb.flushUser(user.getId(), user.getMoney());
								JOptionPane.showMessageDialog(null, "����ɹ�", "����ɹ�", JOptionPane.CLOSED_OPTION);
								
								
								txtCart.setText("���Ĺ��ﳵ����");
								dialog.father.initSelectedPet();
							}
						}
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}

			{
				JButton cancelButton = new JButton("\u53D6\u6D88");
				cancelButton.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						dialog.dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
			{
				txtCart = new JTextPane();
				txtCart.setEditable(false);
				txtCart.setText(CartString());
				txtCart.setFont(new Font("΢���ź�", Font.PLAIN, 19));
				
				contentPanel.setViewportView(txtCart);
			}
		}

		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	private String CartString() {
		StringBuilder sb = new StringBuilder();
		Map<Integer, Integer> map = user.getCart();
		if (map == null) {
			okButton.setEnabled(false);
			return new String("");
		}
		okButton.setEnabled(true);
		// okButton.
		Set<Integer> keys = map.keySet();

		for (Iterator<Pet> it = pets.iterator(); it.hasNext();) {
			Pet pet = it.next();
			int id = pet.getId();
			if (keys.contains(id)) {
				sb.append(String.format("%-20s%s%-20d$%d\n", pet.getName() , "*", map.get(id),
						pet.getPrice() * map.get(id)));
			}
		}

		int sum = user.totalCost(pets);
		sb.append(String.format("%70s$%d", "����:", sum));
		
		if (sum == 0) {
			okButton.setEnabled(false);
			return new String("");
		}
		
		return sb.toString();
	}

}
