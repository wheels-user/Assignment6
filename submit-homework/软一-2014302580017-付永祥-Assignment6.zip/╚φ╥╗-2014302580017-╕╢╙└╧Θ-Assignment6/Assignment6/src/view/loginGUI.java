package view;

import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import Authentication.UserPwdAutentiation;
import bean.User;

public class loginGUI {

	private JFrame frame;
	private JTextField txtUser;
	private JPasswordField txtPwd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginGUI window = new loginGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public loginGUI() {
		initialize();
		this.frame.setTitle("QPet�����ͻ���");
		this.frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 580, 392);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblQpet = new JLabel("QPet\u5BA0\u7269\u5E97\u5BA2\u6237\u7AEF");
		lblQpet.setHorizontalAlignment(SwingConstants.CENTER);
		lblQpet.setBounds(207, 27, 143, 36);
		frame.getContentPane().add(lblQpet);
		
		txtUser = new JTextField();
		txtUser.setBounds(207, 97, 143, 24);
		frame.getContentPane().add(txtUser);
		txtUser.setColumns(10);
		
		txtPwd = new JPasswordField();
		txtPwd.setBounds(207, 167, 143, 24);
		frame.getContentPane().add(txtPwd);
		txtPwd.setColumns(10);
		
		JLabel lblUser = new JLabel("\u7528\u6237\u540D\uFF1A");
		lblUser.setBounds(112, 100, 72, 18);
		frame.getContentPane().add(lblUser);
		
		JLabel lblPwd = new JLabel("\u5BC6\u7801\uFF1A");
		lblPwd.setBounds(112, 170, 72, 18);
		frame.getContentPane().add(lblPwd);
		
		JButton btnLogin = new JButton("\u767B\u5F55");
		btnLogin.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				String username = txtUser.getText().trim();
				String pwd = new String(txtPwd.getPassword());
				
				UserPwdAutentiation upa = new UserPwdAutentiation();
				User curUser = upa.autentiation(username, pwd);
				if(curUser != null){
					new StoreGUI(curUser);
					curUser.flush();
					frame.dispose();
				}
				else
					JOptionPane.showMessageDialog(frame, "���������û���������", "��¼ʧ��", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnLogin.setBounds(389, 131, 113, 27);
		frame.getContentPane().add(btnLogin);
		
		JButton btnRegister = new JButton("\u6CE8\u518C");
		btnRegister.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				new RegisterGUI();
			}
		});
		btnRegister.setBounds(389, 242, 113, 27);
		frame.getContentPane().add(btnRegister);
		
		
		//JLabel lblTip = new JLabel("<html><body>����<br />����</body></html>");
		JLabel lblTip = new JLabel("<html><body>\u8FD8\u6CA1\u6709\u8D26\u53F7\uFF1F\u5148\u6CE8\u518C\u4E00\u4E2A\u8D26\u53F7\u5427<br/>\u73B0\u5728\u6CE8\u518C\u5C06\u7ACB\u5373\u83B7\u5F97\u4F1A\u5458\u4E13\u4EAB\u8D85\u7EA7\u4F18\u60E0\u52385000$</body></html>");
		lblTip.setBounds(112, 244, 263, 65);
		frame.getContentPane().add(lblTip);
		
		

	}
}
