package view.model;

import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class MyPanel {
	private JPanel panel;
	private JSpinner spinner;
	private JLabel label;
	private static JPanel panel_Main;
	private static boolean isInit = false;
	private static int count = 0;
	private static final int height = 34;
	private static final int width = 1083;
	
	public MyPanel(String s){
		
		if(!isInit) return;
		  	panel = new JPanel();
		    panel.setBounds(0,count * height, width, height);
		    panel_Main.add(panel);
		    panel.setLayout(null);
		    
		    spinner = new JSpinner();
		    spinner.setBounds(1041, 0, 42, 34);
		    spinner.setModel(new SpinnerNumberModel(0,0,1000, 1));
		    panel.add(spinner);
		    
		    label = new JLabel(s);
		    label.setFont(new Font("����", Font.PLAIN, 22));
		    label.setBounds(0, 0, 1041/*889*/, 34);
		    panel.add(label);
		    
		    count++;
	}
	
	public static void init(JPanel jpanel){
		panel_Main = jpanel;
		isInit = true;
	}
}
