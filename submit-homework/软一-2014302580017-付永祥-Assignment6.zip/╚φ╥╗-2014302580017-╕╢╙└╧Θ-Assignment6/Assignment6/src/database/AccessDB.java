package database;

import java.sql.*;

public class AccessDB {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/my_schema";

	// Database credentials
	static String USER = "root";
	static String PASS = "123456";

	private Connection conn = null;
	private Statement stmt = null;

	public AccessDB() {
		init();
	}
	
	public ResultSet getPets(){
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			String sql;
			sql = "select * from 2014302580017_pet;";
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return rs;
	}

	public void flushUser(int id,int money) {
		try {
			stmt = conn.createStatement();
			String sql;
			sql = "update 2014302580017_userinfos set money = " + money + " where id = "+id+";";
			stmt.execute(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public int Register(String username, String pwd, String email) {

		try {
			stmt = conn.createStatement();
			String sql;

			sql = "create table if not exists 2014302580017_userInfos(id int unsigned not null auto_increment primary key,username char(40) not null,password char(17) not null,money int null default 0,email char(30) not null);";
			stmt.execute(sql);

			sql = "insert into 2014302580017_userInfos values(NULL," + "\"" + username + "\",\"" + pwd + "\",5000,\"" + email
					+ "\");";
			stmt.execute(sql);

			sql = "select id from 2014302580017_userInfos where username = '" + username + "';";
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			return rs.getInt("id");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public ResultSet getAllUserInfos() {
		String sql = "select id,username,password from 2014302580017_userinfos;";
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	public ResultSet getUserById(int id) {
		String sql = "select * from 2014302580017_userinfos where id = " + id + ";";
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	public void close() {

		try {
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void init() {

		try {
			// STEP 1: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");

			// STEP 2: Open a connection
			// System.out.println("DataBase: Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			// STEP 3: Execute a query
			// System.out.println("DataBase: Creating statement...");
			stmt = conn.createStatement();

		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		}
		// System.out.println("DataBase: Goodbye!");

	}
}
