package bean;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import database.AccessDB;

public class User {
	private int id;
	private String username;
	private String password;
	private String email;
	private int money;
	private Map<Integer, Integer> cart = null;
	
	public User(int id, String username, String password, String email, int money) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.email = email;
		this.money = money;
	}
	
	public static void main(String[] args){
		
	}
	
	public int totalCost(Vector<Pet> pets){
		int sum = 0;
		if(cart == null) return 0;
		Set<Integer> keys = cart.keySet();
		
		for(Iterator<Pet> it = pets.iterator();it.hasNext();){
			Pet pet = it.next();
			int id = pet.getId();
			if(keys.contains(id)){
				sum+= pet.getPrice()*cart.get(id);
			}
		}
		return sum;
	}
	
	public void flush(){
			AccessDB adb = new AccessDB();
			adb.flushUser(id, money);
			adb.close();
	}
	
	public void addToCart(Map<Integer, Integer> map){
		/*if(cart == null) {
			cart = map;
			return;
		}
		
		Set<Integer> keys = map.keySet();
		for(Iterator<Integer> it = keys.iterator();it.hasNext();){
			int key = it.next();
			cart.put(key, map.get(key));
		}*/
		cart = map;
	}
	
	public Map<Integer, Integer> getCart(){
		return cart;
	}
	
	@SuppressWarnings("finally")
	public static User getUserById(int id){
		User u = null;
		try {
			AccessDB adb = new AccessDB();
			ResultSet rs = adb.getUserById(id);
			rs.next();
			u = new User(id, rs.getString("username"), rs.getString("password"), rs.getString("email"), rs.getInt("money"));
			return u;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			return u;
		}
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", password=" + password + ", email=" + email + ", money="
				+ money + "]";
	}
	
	
}
