package bean;

public class Pet {
	private int id;
	private String name;
	private String eat;
	private String drink;
	private String live;
	private String hobby;
	private int price;
	
	public Pet(int id, String name, String eat, String drink, String live, String hobby,int price) {
		super();
		this.id = id;
		this.name = name;
		this.eat = eat;
		this.drink = drink;
		this.live = live;
		this.hobby = hobby;
		this.price = price;
	}
	
	public int getPrice() {
		return price;
	}
	
	public void setId(int price) {
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getEat() {
		return eat;
	}

	public String getDrink() {
		return drink;
	}

	public String getLive() {
		return live;
	}

	public String getHobby() {
		return hobby;
	}

	@Override
	public String toString() {
		return String.format("%-5d%-10s%-17s%-12s%-26s%-13s$%-10d", id,name,eat,drink,live,hobby,price);
	}
	
	
}
