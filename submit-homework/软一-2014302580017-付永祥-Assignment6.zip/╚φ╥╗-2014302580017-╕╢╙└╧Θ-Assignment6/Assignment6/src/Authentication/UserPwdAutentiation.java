package Authentication;

import java.sql.ResultSet;
import java.sql.SQLException;

import bean.User;
import database.AccessDB;



public class UserPwdAutentiation {
	private AccessDB adb;
	public UserPwdAutentiation(){
		adb = new AccessDB();
	}
	
	public User autentiation(String username,String password){	
		ResultSet rs = adb.getAllUserInfos();
		try {
			while(rs.next()){
				if(username.equals(rs.getString("username")))
					if(password.equals(rs.getString("password"))){
						
						int id = rs.getInt("id");
						User theuser = User.getUserById(id);
						
						return theuser;
					}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	public void close(){
		adb.close();
	}
}
